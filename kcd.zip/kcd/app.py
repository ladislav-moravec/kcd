import os
import re
import json
import datetime
from flask import Flask, send_from_directory, jsonify, request
from utils import config, create_ssh_client, run_ssh_command
from update_data import run_update
from update_consumer_groups import get_single_group_lag

LAST_CONSUME_TIME = None

# Initialize Flask app, we will serve static files from the current directory
app = Flask(__name__, static_url_path='', static_folder='.')

@app.route('/')
def index():
    """Serves the main index.html page."""
    return send_from_directory('.', 'index.html')

@app.route('/data/<path:filename>')
def serve_data(filename):
    """Serves JSON data from the data/ folder."""
    return send_from_directory('data', filename)

@app.route('/api/refresh', methods=['POST'])
def refresh_data():
    """API endpoint to run the update script (respecting the cooldown limit)."""
    # Triggers the logic in update_data.py
    success, message = run_update(force=False)
    
    # Send response to frontend
    return jsonify({
        'success': success,
        'message': message,
        'cooldownSeconds': int(config.get("refresh_cooldown_minutes", 5) * 60)
    })

@app.route('/api/refresh_lag', methods=['GET'])
def refresh_lag():
    """API endpoint for an immediate re-fetch of a single lag value."""
    env = request.args.get('env')
    group = request.args.get('group')
    if not env or not group:
        return jsonify({'success': False, 'message': 'Missing env or group parameters'})
        
    val = get_single_group_lag(env, group)
    return jsonify({
        'success': True,
        'lag': val
    })





@app.route('/api/consume', methods=['GET'])
def consume_messages():
    """API endpoint to consume last 10 messages from a topic."""
    global LAST_CONSUME_TIME
    env = request.args.get('env')
    topic = request.args.get('topic')
    
    if not env or not topic:
        return jsonify({'success': False, 'message': 'Missing env or topic parameters'})
        
    now = datetime.datetime.now()
    if LAST_CONSUME_TIME:
        delta = now - LAST_CONSUME_TIME
        if delta.total_seconds() < 60:
            remaining = int(60 - delta.total_seconds())
            return jsonify({'success': False, 'message': f'Please wait {remaining}s before consuming messages again.'}), 429
            
    if not re.match(r'^[a-zA-Z0-9_\.-]+$', topic):
        return jsonify({'success': False, 'message': 'Invalid topic format'})
        
    env_config = config.get("environments", {}).get(env)
    if not env_config:
        return jsonify({'success': False, 'message': 'Invalid environment'})
        
    LAST_CONSUME_TIME = now
    
    ssh_host = env_config.get("ssh_host")
    client = create_ssh_client(ssh_host)
    if not client:
        LAST_CONSUME_TIME = None
        return jsonify({'success': False, 'message': 'Failed to connect via SSH'})
        
    try:
        # Use timeout 15s to prevent hanging on empty topics
        cmd = f"timeout 15s kafkactl consume {topic} --tail 10 -o json"
        output = run_ssh_command(client, cmd)
        client.close()
        
        if output is None:
            return jsonify({'success': False, 'message': 'Command failed or timed out (topic might be empty).'})
            
        messages = []
        import json
        
        output_cleaned = output.strip()
        
        # Find the first occurrence of a JSON object or array to skip shell garbage (e.g. "ls: cannot access...")
        idx_brace = output_cleaned.find('{')
        idx_bracket = output_cleaned.find('[')
        first_json = -1
        if idx_brace != -1 and idx_bracket != -1:
            first_json = min(idx_brace, idx_bracket)
        else:
            first_json = max(idx_brace, idx_bracket)
            
        if first_json != -1:
            json_text = output_cleaned[first_json:]
            decoder = json.JSONDecoder()
            while json_text:
                json_text = json_text.lstrip()
                if not json_text:
                    break
                try:
                    obj, index = decoder.raw_decode(json_text)
                    messages.append(obj)
                    json_text = json_text[index:]
                except json.JSONDecodeError:
                    # Skip 1 char and search for the next JSON structure
                    next_brace = json_text.find('{', 1)
                    next_bracket = json_text.find('[', 1)
                    next_idx = -1
                    if next_brace != -1 and next_bracket != -1:
                        next_idx = min(next_brace, next_bracket)
                    else:
                        next_idx = max(next_brace, next_bracket)
                        
                    if next_idx != -1:
                        json_text = json_text[next_idx:]
                    else:
                        break
        
        # Fallback to line by line if raw_decode fails entirely
        if not messages and output.strip():
            for line in output.splitlines():
                line = line.strip()
                if line.startswith('{') and line.endswith('}'):
                    try:
                        messages.append(json.loads(line))
                    except:
                        pass
                        
        if len(messages) == 1 and isinstance(messages[0], list):
            messages = messages[0]
                    
        return jsonify({'success': True, 'data': messages, 'raw': output})
    except Exception as e:
        return jsonify({'success': False, 'message': str(e)})

if __name__ == '__main__':
    # In OpenShift, the app typically runs on port 8080
    app.run(host='0.0.0.0', port=8080, debug=True)
