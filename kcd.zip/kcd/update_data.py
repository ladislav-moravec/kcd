#!/usr/bin/env python3
import json
import logging
import re
import os
import datetime
from utils import config, check_cooldown, trigger_cooldown, create_ssh_client, run_ssh_command, ensure_dir
from update_consumer_groups import run_update_cgroups

def process_topics_and_acls(env_name, env_cfg):
    """Downloads topics and ACLs data via SSH and saves it."""
    output_dir = ensure_dir(env_name)
    ssh_host = env_cfg.get("ssh_host")
    
    ssh = create_ssh_client(ssh_host)
    if not ssh:
        return
        
    # 1. Load topics
    topics_json_string = run_ssh_command(ssh, "kafkactl get topics -o json", is_json=True)
    if topics_json_string:
        try:
            raw_topics = json.loads(topics_json_string)
            formatted_topics = []
            for t in raw_topics:
                topic_name = t.get("Name", t.get("name", "N/A"))
                
                if topic_name.startswith("_"):
                    project_name = "System (Internal)"
                elif topic_name.startswith("dlq-"):
                    extracted = topic_name.replace("dlq-", "").split(".")[0]
                    project_name = f"DLQ - {extracted.upper()}"
                elif "." in topic_name:
                    project_name = topic_name.split(".")[0].upper()
                else:
                    project_name = "Other / Test"

                configs = t.get("Configs", t.get("configs", {}))
                retention_ms = "-"
                cleanup_policy = "-"
                max_message_bytes = "-"
                
                if isinstance(configs, dict):
                    retention_ms = configs.get("retention.ms", "-")
                    cleanup_policy = configs.get("cleanup.policy", "-")
                    max_message_bytes = configs.get("max.message.bytes", "-")
                elif isinstance(configs, list):
                    for c in configs:
                        name = c.get("Name", c.get("name", ""))
                        if name == "retention.ms":
                            retention_ms = c.get("Value", c.get("value", "-"))
                        elif name == "cleanup.policy":
                            cleanup_policy = c.get("Value", c.get("value", "-"))
                        elif name == "max.message.bytes":
                            max_message_bytes = c.get("Value", c.get("value", "-"))

                formatted_topics.append({
                    "project": project_name,
                    "name": topic_name,
                    "partitions": len(t.get("Partitions", [])),
                    "replicas": len(t.get("Partitions", [{}])[0].get("Replicas", [])) if isinstance(t.get("Partitions"), list) and len(t.get("Partitions")) > 0 and isinstance(t.get("Partitions")[0], dict) else 0,
                    "retention": retention_ms,
                    "cleanupPolicy": cleanup_policy,
                    "maxMessageBytes": max_message_bytes
                })
            
            with open(os.path.join(output_dir, "topics.json"), "w", encoding='utf-8') as f:
                json.dump(formatted_topics, f, indent=4)
            logging.info(f"[{env_name}] Topics successfully saved.")
        except json.JSONDecodeError:
            logging.error(f"[{env_name}] Command did not return valid JSON.")

    # 2. Load ACLs
    acls_output_string = run_ssh_command(ssh, "kafkactl get access-control-list")
    if acls_output_string:
        try:
            if acls_output_string.strip().startswith('['):
                raw_acls = json.loads(acls_output_string)
                formatted_acls = []
                for a in raw_acls:
                    formatted_acls.append({
                         "principal": a.get("Principal", "N/A"),
                         "resourceType": a.get("ResourceType", "N/A"),
                         "resourceName": a.get("ResourceName", "N/A"),
                         "host": a.get("Host", "*"),
                         "operation": a.get("Operation", "N/A"),
                         "permissionType": a.get("PermissionType", "N/A")
                     })
            else:
                formatted_acls = []
                lines = acls_output_string.strip().split('\n')
                
                header_idx = -1
                for idx, line in enumerate(lines):
                    if "PRINCIPAL" in line.upper():
                        header_idx = idx
                        break
                        
                if header_idx != -1 and len(lines) > header_idx:
                    headers = [h.strip().lower().replace(" ", "").replace("_", "") for h in re.split(r'\s{2,}', lines[header_idx].strip())]
                    
                    for line in lines[header_idx+1:]:
                        if not line.strip(): continue
                        parts = [p.strip() for p in re.split(r'\s{2,}', line.strip())]
                        
                        if len(parts) >= 2:
                            row_dict = dict(zip(headers, parts))
                            formatted_acls.append({
                                "principal": row_dict.get("principal", ""),
                                "resourceType": row_dict.get("resourcetype", ""),
                                "resourceName": row_dict.get("resourcename", ""),
                                "host": row_dict.get("host", ""),
                                "operation": row_dict.get("operation", ""),
                                "permissionType": row_dict.get("permission", row_dict.get("permissiontype", ""))
                            })

            with open(os.path.join(output_dir, "acls.json"), "w", encoding='utf-8') as f:
                json.dump(formatted_acls, f, indent=4)
            logging.info(f"[{env_name}] ACLs successfully saved.")
        except Exception as ex:
            logging.error(f"[{env_name}] Failed to parse ACL output: {ex}")

    # 3. Metadata
    metadata = {
        "lastUpdated": datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    }
    with open(os.path.join(output_dir, "metadata.json"), "w", encoding='utf-8') as f:
        json.dump(metadata, f, indent=4)
    logging.info(f"[{env_name}] Metadata generated.")

    ssh.close()

def run_update(force=False):
    """Main function to update everything (Topics, ACLs, and Consumer Groups)."""
    is_skipped, msg = check_cooldown(force)
    if is_skipped:
         return False, msg

    environments = config.get("environments", {})
    for env_name, env_cfg in environments.items():
        logging.info(f"=== TOPICS & ACLS [{env_name.upper()}] ===")
        try:
            process_topics_and_acls(env_name, env_cfg)
        except Exception as e:
            logging.error(f"Error processing topics/acls for {env_name}: {e}")

    # Explicitly run consumer groups portion next, skipping its internal cooldown
    # so we update it directly within this global run
    cgroup_success, cgroup_msg = run_update_cgroups(force=True)
    if not cgroup_success:
        logging.error(f"Consumer groups sub-task failed: {cgroup_msg}")
            
    # Set global timestamp once total process is done
    trigger_cooldown()
    return True, "Data synchronization successful."

def main():
    # If script runs directly from shell, overwrite cooldown limits
    run_update(force=True)

if __name__ == "__main__":
    main()