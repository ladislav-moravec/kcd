import json
import logging
import os
import paramiko
import datetime

# Setup logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')

# Global reference for cooldown handling
LAST_REFRESH_TIME = None

def load_config():
    """Loads configuration from config.json."""
    config_path = os.path.join(os.path.dirname(__file__), 'config.json')
    if not os.path.exists(config_path):
        logging.error(f"Config file not found: {config_path}")
        return {}
    with open(config_path, 'r', encoding='utf-8') as f:
        return json.load(f)

# Initialize config
config = load_config()

def check_cooldown(force=False):
    """
    Checks if the global cooldown has passed.
    Returns (True, message) if update skips, (False, '') if allows.
    """
    global LAST_REFRESH_TIME
    if force or LAST_REFRESH_TIME is None:
        return False, ""

    now = datetime.datetime.now()
    cooldown_minutes = config.get("refresh_cooldown_minutes", 5)
    delta = now - LAST_REFRESH_TIME
    
    if delta.total_seconds() < (cooldown_minutes * 60):
        remaining = int((cooldown_minutes * 60) - delta.total_seconds())
        val_sec = remaining % 60
        val_min = remaining // 60
        msg = f"Data was recently refreshed. Please wait {val_min}m {val_sec}s before attempting again."
        logging.info(f"Update skipped (cooldown active): {msg}")
        return True, msg
        
    return False, ""

def trigger_cooldown():
    """Updates the last refresh time to now."""
    global LAST_REFRESH_TIME
    LAST_REFRESH_TIME = datetime.datetime.now()

def create_ssh_client(ssh_host):
    """Creates and connects an SSH client based on config."""
    ssh_user = config.get("ssh_user")
    ssh_key_path = config.get("ssh_key_path")
    
    ssh = paramiko.SSHClient()
    ssh.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    
    try:
        logging.info(f"Connecting to {ssh_host}...")
        ssh.connect(ssh_host, username=ssh_user, key_filename=ssh_key_path)
        return ssh
    except Exception as e:
        logging.error(f"Failed to connect to {ssh_host}: {e}")
        return None

def run_ssh_command(ssh_client, command, is_json=False):
    """Executes a command via SSH under the kafka user and returns stdout."""
    logging.info(f"Executing command under kafka user: {command}")
    
    sudo_command = f"""sudo su - kafka << 'EOF'
bash -lc '{command}'
EOF
"""
    stdin, stdout, stderr = ssh_client.exec_command(sudo_command, get_pty=True)
    exit_status = stdout.channel.recv_exit_status()
    output = stdout.read().decode('utf-8')
    
    if exit_status != 0:
        error_msg = stderr.read().decode().strip()
        logging.error(f"Command execution error ({exit_status}): {error_msg}")
        return None
        
    if is_json:
        try:
            json_start_idx = output.find('[')
            if json_start_idx != -1:
                clean_json = output[json_start_idx:]
                json_end_idx = clean_json.rfind(']')
                if json_end_idx != -1:
                    return clean_json[:json_end_idx+1]
            return output
        except Exception:
            return output
            
    lines = output.split('\n')
    clean_lines = [line for line in lines if not line.strip().startswith("Last login")]
    return '\n'.join(clean_lines)

def ensure_dir(env_name):
    """Ensures the output directory exists for the given environment."""
    base_dir = config.get("base_output_dir", "data")
    output_dir = os.path.join(base_dir, env_name)
    os.makedirs(output_dir, exist_ok=True)
    return output_dir
