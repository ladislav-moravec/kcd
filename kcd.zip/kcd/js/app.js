        document.addEventListener("DOMContentLoaded", () => {
            
            // Dark Mode Toggle Logic
            const htmlElement = document.documentElement;
            const themeToggleBtn = document.getElementById('themeToggle');
            
            // Detect saved theme or start with dark implementation
            const savedTheme = localStorage.getItem('theme') || 'dark';
            htmlElement.setAttribute('data-bs-theme', savedTheme);
            themeToggleBtn.textContent = savedTheme === 'dark' ? '☀️' : '🌙';

            themeToggleBtn.addEventListener('click', () => {
                const currentTheme = htmlElement.getAttribute('data-bs-theme');
                const newTheme = currentTheme === 'dark' ? 'light' : 'dark';
                htmlElement.setAttribute('data-bs-theme', newTheme);
                localStorage.setItem('theme', newTheme);
                themeToggleBtn.textContent = newTheme === 'dark' ? '☀️' : '🌙';
            });

            let topicsData = [];
            let aclsData = [];
            let cgroupsData = [];

            // Variables for CSV export access
            let activeFiltersData = {
                topics: [],
                acls: [],
                cgroups: []
            };

            // Pagination and Sorting Variables
            let pageSize = 50;
            let currentTab = 'topics';
            let paginationState = {
                topics: { page: 1, total: 0 },
                acls: { page: 1, total: 0 },
                cgroups: { page: 1, total: 0 }
            };
            let sortingState = {
                topics: { column: null, ascending: true },
                acls: { column: null, ascending: true },
                cgroups: { column: null, ascending: true }
            };

            const pageSizeSelect = document.getElementById('pageSizeSelect');
            const btnPrevPage = document.getElementById('btnPrevPage');
            const btnNextPage = document.getElementById('btnNextPage');
            const pageIndicator = document.getElementById('pageIndicator');
            
            // Helper function to show bootstrap toasts
            function showToast(message, type = 'info') {
                const toastContainer = document.getElementById('toastContainer');
                const toastEl = document.createElement('div');
                toastEl.className = `toast align-items-center text-bg-${type} border-0 mb-2`;
                toastEl.setAttribute('role', 'alert');
                toastEl.setAttribute('aria-live', 'assertive');
                toastEl.setAttribute('aria-atomic', 'true');
                toastEl.innerHTML = `
                    <div class="d-flex">
                        <div class="toast-body">
                            ${message}
                        </div>
                        <button type="button" class="btn-close btn-close-white me-2 m-auto" data-bs-dismiss="toast" aria-label="Close"></button>
                    </div>
                `;
                toastContainer.appendChild(toastEl);
                const bsToast = new bootstrap.Toast(toastEl, { delay: 4000 });
                bsToast.show();
                toastEl.addEventListener('hidden.bs.toast', () => {
                    toastEl.remove();
                });
            }

            // Sorting logic function
            function sortArray(array, column, ascending) {
                if (!column) return array;
                return array.sort((a, b) => {
                    let valA = a[column];
                    let valB = b[column];
                    
                    if (valA === undefined || valA === null) valA = '';
                    if (valB === undefined || valB === null) valB = '';
                    
                    // Try numeric sort first if applicable (like partitions, replicas)
                    let numA = parseFloat(valA);
                    let numB = parseFloat(valB);
                    if (!isNaN(numA) && !isNaN(numB)) {
                        return ascending ? numA - numB : numB - numA;
                    }
                    
                    // Fallback to string comparison
                    let strA = String(valA).toLowerCase();
                    let strB = String(valB).toLowerCase();
                    if (strA < strB) return ascending ? -1 : 1;
                    if (strA > strB) return ascending ? 1 : -1;
                    return 0;
                });
            }

            // Bind click events on sortable headers
            document.querySelectorAll('.sortable').forEach(th => {
                th.addEventListener('click', () => {
                    const tab = th.getAttribute('data-tab');
                    const column = th.getAttribute('data-sort');
                    let isAsc = sortingState[tab].column === column ? !sortingState[tab].ascending : true;
                    
                    sortingState[tab].column = column;
                    sortingState[tab].ascending = isAsc;
                    
                    // Reset all icons in this tab
                    document.querySelectorAll(`.sortable[data-tab="${tab}"] .sort-icon`).forEach(icon => {
                        icon.innerHTML = '&#8693;'; // neutral up/down icon
                        icon.classList.remove('active');
                    });
                    
                    // Set active icon
                    const icon = th.querySelector('.sort-icon');
                    icon.innerHTML = isAsc ? '&#9651;' : '&#9661;'; // thin arrows
                    icon.classList.add('active');
                    
                    applyFilters(false);
                });
            });

            pageSizeSelect.addEventListener('change', (e) => {
                pageSize = parseInt(e.target.value, 10);
                applyFilters(true);
            });

            btnPrevPage.addEventListener('click', () => {
                if (paginationState[currentTab].page > 1) {
                    paginationState[currentTab].page--;
                    applyFilters(false);
                }
            });

            btnNextPage.addEventListener('click', () => {
                const state = paginationState[currentTab];
                const totalPages = Math.ceil(state.total / pageSize) || 1;
                if (state.page < totalPages) {
                    state.page++;
                    applyFilters(false);
                }
            });

            // Initialize logic: URL parsing to restore state
            function initializeFromUrl() {
                const params = new URLSearchParams(window.location.search);
                
                // Set Tab
                const tabParam = params.get('tab');
                if (tabParam && ['topics', 'acls', 'cgroups'].includes(tabParam)) {
                    currentTab = tabParam;
                    const tabBtn = document.getElementById(`${tabParam}-tab`);
                    if (tabBtn) new bootstrap.Tab(tabBtn).show();
                }
                
                // Set Global Search
                if (params.has('search')) {
                    document.getElementById('searchInput').value = params.get('search');
                }
                
                // Set per-column filter inputs
                document.querySelectorAll('.column-filter').forEach(input => {
                    const id = input.id;
                    if (params.has(id)) {
                        input.value = params.get(id);
                    }
                });
            }

            // Sync filters state to URL
            function updateUrlParams() {
                const params = new URLSearchParams();
                
                params.set('tab', currentTab);
                
                const searchVal = document.getElementById('searchInput').value;
                if (searchVal) params.set('search', searchVal);
                
                document.querySelectorAll('.column-filter').forEach(input => {
                    if (input.value) {
                        params.set(input.id, input.value);
                    }
                });
                
                const newUrl = `${window.location.pathname}?${params.toString()}`;
                window.history.replaceState({}, '', newUrl);
            }

            // Bind CSV Export
            document.getElementById('btnExportCsv').addEventListener('click', () => {
                let columnsMap;
                let dataToExport = activeFiltersData[currentTab];
                let filename = `kafka_${currentTab}_export.csv`;

                if (dataToExport.length === 0) {
                    showToast('No data available to export.', 'warning');
                    return;
                }

                if (currentTab === 'topics') {
                    columnsMap = ['project', 'name', 'partitions', 'replicas', 'retention', 'maxMessageBytes', 'cleanupPolicy'];
                } else if (currentTab === 'acls') {
                    columnsMap = ['principal', 'resourceType', 'resourceName', 'role', 'host', 'operation', 'permissionType'];
                } else if (currentTab === 'cgroups') {
                    columnsMap = ['consumerGroup', 'topics', 'lag'];
                }

                let csvContent = "data:text/csv;charset=utf-8,";
                csvContent += columnsMap.join(",") + "\r\n";

                dataToExport.forEach(rowItem => {
                    let rowHtml = columnsMap.map(col => {
                        let cell = rowItem[col] === undefined || rowItem[col] === null ? '' : String(rowItem[col]);
                        // Escape quotes
                        return `"${cell.replace(/"/g, '""')}"`;
                    });
                    csvContent += rowHtml.join(",") + "\r\n";
                });

                const encodedUri = encodeURI(csvContent);
                const link = document.createElement("a");
                link.setAttribute("href", encodedUri);
                link.setAttribute("download", filename);
                document.body.appendChild(link);
                link.click();
                link.remove();
                
                showToast('CSV download completely successfully!', 'success');
            });

            // Modify Tab change event to save URL
            document.querySelectorAll('button[data-bs-toggle="tab"]').forEach(tabEl => {
                tabEl.addEventListener('shown.bs.tab', event => {
                    currentTab = event.target.getAttribute('data-bs-target').replace('#', '');
                    updatePaginationUI();
                    updateUrlParams();
                });
            });

            function getPageData(data, tab) {
                const state = paginationState[tab];
                state.total = data.length;
                const totalPages = Math.ceil(state.total / pageSize) || 1;
                if (state.page > totalPages) state.page = totalPages;
                if (state.page < 1) state.page = 1;
                
                const start = (state.page - 1) * pageSize;
                return data.slice(start, start + pageSize);
            }

            function updatePaginationUI() {
                const state = paginationState[currentTab];
                const totalPages = Math.ceil(state.total / pageSize) || 1;
                pageIndicator.textContent = `Page ${state.page} of ${totalPages} (Total: ${state.total})`;
                btnPrevPage.disabled = state.page <= 1;
                btnNextPage.disabled = state.page >= totalPages;
            }

            // Fetch Data Function
            function loadDataForEnv(env) {
                // Clear existing data
                topicsData = [];
                aclsData = [];
                cgroupsData = [];
                document.getElementById('lastUpdated').innerHTML = `<strong>Last updated:</strong> Loading...`;
                document.getElementById('topicsBody').innerHTML = '';
                document.getElementById('aclsBody').innerHTML = '';
                document.getElementById('cgroupsBody').innerHTML = '';

                const cacheBuster = new Date().getTime();

                // Fetch and render Topics
                fetch(`data/${env}/topics.json?t=${cacheBuster}`)
                    .then(response => response.ok ? response.json() : [])
                    .then(data => {
                        topicsData = data;
                        applyFilters(true);
                    })
                    .catch(err => {
                        console.error(`Error loading topics for ${env}:`, err);
                        topicsData = [];
                        applyFilters(true);
                    });

                // Fetch and render ACLs
                fetch(`data/${env}/acls.json?t=${cacheBuster}`)
                    .then(response => response.ok ? response.json() : [])
                    .then(data => {
                        aclsData = data;
                        applyFilters(true);
                    })
                    .catch(err => {
                        console.error(`Error loading ACLs for ${env}:`, err);
                        aclsData = [];
                        applyFilters(true);
                    });

                // Fetch and render Consumer Groups
                fetch(`data/${env}/consumer_groups.json?t=${cacheBuster}`)
                    .then(response => response.ok ? response.json() : [])
                    .then(data => {
                        cgroupsData = data;
                        applyFilters(true);
                    })
                    .catch(err => {
                        console.error(`Error loading consumer groups for ${env}:`, err);
                        cgroupsData = [];
                        applyFilters(true);
                    });

                // Fetch Metadata
                fetch(`data/${env}/metadata.json?t=${cacheBuster}`)
                    .then(response => response.ok ? response.json() : {})
                    .then(data => {
                        if(data.lastUpdated) {
                            document.getElementById('lastUpdated').innerHTML = `<strong>Last updated:</strong> ${data.lastUpdated}`;
                        } else {
                            document.getElementById('lastUpdated').innerHTML = `<strong>Last updated:</strong> Not available`;
                        }
                    })
                    .catch(err => {
                         console.error(`Error loading metadata for ${env}:`, err);
                         document.getElementById('lastUpdated').innerHTML = `<strong>Last updated:</strong> Error`;
                    });
            }

            // Initial Load for QA
            initializeFromUrl();
            loadDataForEnv('qa');

            // Handle Environment Selection
            document.querySelectorAll('input[name="envRadio"]').forEach(radio => {
                radio.addEventListener('change', (e) => {
                    if (e.target.checked) {
                        loadDataForEnv(e.target.value);
                    }
                });
            });

            // Refresh API logic
            document.getElementById('btnRefresh').addEventListener('click', () => {
                const btn = document.getElementById('btnRefresh');
                const icon = document.getElementById('refreshIcon');
                const text = document.getElementById('refreshText');
                const progressBar = document.getElementById('refreshProgressBar');
                
                // Zámek tlačítka + indikace 
                btn.disabled = true;
                icon.innerHTML = '⏳';
                text.innerHTML = 'Fetching...';
                
                // Show Progress Bar
                progressBar.classList.remove('d-none');
                showToast('Refresh data request sent. Please wait...', 'primary');
                
                fetch('/api/refresh', { method: 'POST' })
                    .then(response => {
                        if (!response.ok) {
                            throw new Error(`HTTP error! status: ${response.status}`);
                        }
                        return response.json();
                    })
                    .then(res => {
                        if (res.success) {
                            // Refreshne se prostředí, které je zrovna zaškrtnuté
                            const activeEnv = document.querySelector('input[name="envRadio"]:checked').value;
                            loadDataForEnv(activeEnv);
                            
                            showToast('Data was successfully refreshed and synced!', 'success');
                            
                            // Spuštění vizuálního cooldown timeru získaného přímo z backendu
                            const cdSeconds = res.cooldownSeconds || 300;
                            startCooldownTimer(cdSeconds); 
                        } else {
                            // Backend rejected explicitly (due to its own cooldown most likely) 
                            // Try parsing backend seconds if available, otherwise just use a short reset
                            const match = res.message.match(/wait (\d+)m (\d+)s/);
                            if (match) {
                                const remainingTotalSecs = parseInt(match[1]) * 60 + parseInt(match[2]);
                                showToast(`Skipped: Refresh cooldown active. Try again later.`, 'warning');
                                startCooldownTimer(remainingTotalSecs);
                            } else {
                                showToast(`Skipped: ${res.message}`, 'warning');
                                resetRefreshButton();
                            }
                        }
                    })
                    .catch(err => {
                        console.error('API Refresh failed:', err);
                        showToast('API Call failed. Is the Flask server running?', 'danger');
                        resetRefreshButton();
                    })
                    .finally(() => {
                        // Hide Progress Bar
                        progressBar.classList.add('d-none');
                    });
            });
            
            function resetRefreshButton() {
                const btn = document.getElementById('btnRefresh');
                const icon = document.getElementById('refreshIcon');
                const text = document.getElementById('refreshText');
                btn.disabled = false;
                icon.innerHTML = '↻';
                text.innerHTML = 'Refresh Data';
            }
            
            let cooldownInterval;
            function startCooldownTimer(secondsLeft) {
                const btn = document.getElementById('btnRefresh');
                const icon = document.getElementById('refreshIcon');
                const text = document.getElementById('refreshText');
                
                // Zajistíme, že tlačítko zůstane zamčené
                btn.disabled = true;
                icon.innerHTML = '⏱';
                
                // Uklizení předchozího intervalu, pokud existuje
                if (cooldownInterval) clearInterval(cooldownInterval);
                
                const updateDisplay = () => {
                    if (secondsLeft <= 0) {
                        clearInterval(cooldownInterval);
                        resetRefreshButton();
                        return;
                    }
                    const m = Math.floor(secondsLeft / 60);
                    const s = secondsLeft % 60;
                    text.innerHTML = `Wait ${m}m ${s.toString().padStart(2, '0')}s`;
                    secondsLeft--;
                };
                
                updateDisplay(); // Zobrazit okamžitě počáteční stav
                cooldownInterval = setInterval(updateDisplay, 1000);
            }

            // Role evaluation logic separated for reuse in filters
            function getRoleName(operation) {
                const op = (operation || '').toLowerCase();
                if (op === 'read') return 'Consumer';
                if (op === 'write') return 'Producer';
                if (['all', 'alter', 'alterconfigs', 'delete', 'create'].includes(op)) return 'Admin / Owner';
                if (['describe', 'describeconfigs'].includes(op)) return 'Viewer';
                return operation;
            }

            // Filtering Logic
            function applyFilters(resetPage = true) {
                if (resetPage) {
                    paginationState.topics.page = 1;
                    paginationState.acls.page = 1;
                    paginationState.cgroups.page = 1;
                }
                
                const globalTerm = document.getElementById('searchInput').value.toLowerCase();
                
                // Topics Column Filters
                const fTopProj = document.getElementById('f-top-proj').value.toLowerCase();
                const fTopName = document.getElementById('f-top-name').value.toLowerCase();
                const fTopPart = document.getElementById('f-top-part').value.toLowerCase();
                const fTopRepl = document.getElementById('f-top-repl').value.toLowerCase();
                const fTopRet  = document.getElementById('f-top-ret').value.toLowerCase();
                const fTopMax  = document.getElementById('f-top-max').value.toLowerCase();
                const fTopCln  = document.getElementById('f-top-clean').value.toLowerCase();

                let filteredTopics = topicsData.filter(t => {
                    const matchesGlobal = Object.values(t).some(val => String(val).toLowerCase().includes(globalTerm));
                    if (!matchesGlobal) return false;
                    
                    return String(t.project || '').toLowerCase().includes(fTopProj) &&
                           String(t.name || '').toLowerCase().includes(fTopName) &&
                           String(t.partitions || '').toLowerCase().includes(fTopPart) &&
                           String(t.replicas || '').toLowerCase().includes(fTopRepl) &&
                           String(t.retention || '').toLowerCase().includes(fTopRet) &&
                           String(t.maxMessageBytes || '').toLowerCase().includes(fTopMax) &&
                           String(t.cleanupPolicy || '').toLowerCase().includes(fTopCln);
                });
                filteredTopics = sortArray(filteredTopics, sortingState.topics.column, sortingState.topics.ascending);
                activeFiltersData.topics = filteredTopics;
                renderTopics(getPageData(filteredTopics, 'topics'));

                // ACLs Column Filters
                const fAclPrin = document.getElementById('f-acl-prin').value.toLowerCase();
                const fAclRtyp = document.getElementById('f-acl-rtype').value.toLowerCase();
                const fAclRnam = document.getElementById('f-acl-rname').value.toLowerCase();
                const fAclRole = document.getElementById('f-acl-role').value.toLowerCase();
                const fAclHost = document.getElementById('f-acl-host').value.toLowerCase();
                const fAclOper = document.getElementById('f-acl-oper').value.toLowerCase();
                const fAclPerm = document.getElementById('f-acl-perm').value.toLowerCase();

                let filteredAcls = aclsData.map(a => ({
                    ...a,
                    // temporary store computed role for sorting/filtering
                    computedRole: getRoleName(a.operation)
                })).filter(a => {
                    const matchesGlobal = Object.values(a).some(val => String(val).toLowerCase().includes(globalTerm));
                    if (!matchesGlobal) return false;

                    const computedRoleStr = a.computedRole.toLowerCase();
                    const permState = a.permissionType ? a.permissionType.toLowerCase() : '';

                    return String(a.principal || '').toLowerCase().includes(fAclPrin) &&
                           String(a.resourceType || '').toLowerCase().includes(fAclRtyp) &&
                           String(a.resourceName || '').toLowerCase().includes(fAclRnam) &&
                           computedRoleStr.includes(fAclRole) &&
                           String(a.host || '').toLowerCase().includes(fAclHost) &&
                           String(a.operation || '').toLowerCase().includes(fAclOper) &&
                           permState.includes(fAclPerm);
                });
                
                // If sorting by role, use computedRole. Otherwise sort by chosen column.
                const sortColAcls = sortingState.acls.column === 'operation' ? 'computedRole' : sortingState.acls.column;
                filteredAcls = sortArray(filteredAcls, sortColAcls, sortingState.acls.ascending);
                activeFiltersData.acls = filteredAcls;
                renderAcls(getPageData(filteredAcls, 'acls'));
                
                // Consumer Groups Column Filters
                const fCgId  = document.getElementById('f-cg-id').value.toLowerCase();
                const fCgTop = document.getElementById('f-cg-top').value.toLowerCase();
                const fCgLag = document.getElementById('f-cg-lag').value.toLowerCase();

                let filteredCgroups = cgroupsData.filter(cg => {
                    const matchesGlobal = Object.values(cg).some(val => String(val).toLowerCase().includes(globalTerm));
                    if (!matchesGlobal) return false;

                    return String(cg.consumerGroup || '').toLowerCase().includes(fCgId) &&
                           String(cg.topics || '').toLowerCase().includes(fCgTop) &&
                           String(cg.lag || '').toLowerCase().includes(fCgLag);
                });
                
                filteredCgroups = sortArray(filteredCgroups, sortingState.cgroups.column, sortingState.cgroups.ascending);
                activeFiltersData.cgroups = filteredCgroups;
                renderConsumerGroups(getPageData(filteredCgroups, 'cgroups'));
                
                updatePaginationUI();
                updateUrlParams();
            }

            // Attach event listeners to all filter inputs
            document.getElementById('searchInput').addEventListener('input', () => applyFilters(true));
            document.querySelectorAll('.column-filter').forEach(input => {
                input.addEventListener('input', () => applyFilters(true));
            });

            // Render Functions
            function renderTopics(data) {
                const tbody = document.getElementById('topicsBody');
                tbody.innerHTML = '';
                data.forEach(item => {
                    const tr = document.createElement('tr');
                    tr.innerHTML = `
                        <td>${item.project || '-'}</td>
                        <td><strong>${item.name}</strong></td>
                        <td>${item.partitions}</td>
                        <td>${item.replicas}</td>
                        <td>${item.retention || '-'}</td>
                        <td>${item.maxMessageBytes || '-'}</td>
                        <td>${item.cleanupPolicy || '-'}</td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary" onclick="consumeTopic(this, '${item.name}')" title="Read last 10 msgs">Consume</button>
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            }

            function renderAcls(data) {
                const tbody = document.getElementById('aclsBody');
                tbody.innerHTML = '';
                data.forEach(item => {
                    let roleBadge = 'bg-secondary';
                    const op = (item.operation || '').toLowerCase();

                    // Using the centralized function
                    let roleName = getRoleName(item.operation);
                    
                    if (roleName === 'Consumer') roleBadge = 'bg-success';
                    else if (roleName === 'Producer') roleBadge = 'bg-primary';
                    else if (roleName === 'Admin / Owner') roleBadge = 'bg-danger';
                    else if (roleName === 'Viewer') roleBadge = 'bg-info text-dark';

                    // Handling explicit Deny permissions
                    const permType = (item.permissionType || '').toLowerCase();
                    let permissionDisplay = item.permissionType;
                    
                    if (permType === 'deny') {
                        roleBadge = 'bg-secondary text-decoration-line-through'; // greyed out with a strike to show it's revoked
                        roleName = roleName + ' (Denied)';
                        permissionDisplay = `<strong class="text-danger">Deny</strong>`;
                    } else if (permType === 'allow') {
                        permissionDisplay = `<span class="text-success">Allow</span>`;
                    }

                    const tr = document.createElement('tr');
                    
                    // Dim the entire row slightly for denied records
                    if (permType === 'deny') {
                        tr.classList.add('opacity-50');
                    }

                    // Formatování Principal (např. User:CN=... -> badge User + zbytek texto)
                    let principalHtml = `<strong>${item.principal || ''}</strong>`;
                    const firstColonIdx = (item.principal || '').indexOf(':');
                    if (firstColonIdx !== -1) {
                        const principalPrefix = item.principal.substring(0, firstColonIdx);
                        const principalValue = item.principal.substring(firstColonIdx + 1);
                        
                        let principalBadgeClass = 'bg-secondary';
                        if (principalPrefix.toLowerCase() === 'user') {
                            principalBadgeClass = 'bg-success'; // Jako "Consumer"
                        } else if (principalPrefix.toLowerCase() === 'group') {
                            principalBadgeClass = 'bg-primary';
                        }

                        principalHtml = `<span class="badge ${principalBadgeClass} me-1 px-2 py-1">${principalPrefix}:</span><strong>${principalValue}</strong>`;
                    }

                    tr.innerHTML = `
                        <td>${principalHtml}</td>
                        <td>${item.resourceType}</td>
                        <td>${item.resourceName}</td>
                        <td><span class="badge ${roleBadge}">${roleName}</span></td>
                        <td>${item.host}</td>
                        <td>${item.operation}</td>
                        <td>${permissionDisplay}</td>
                    `;
                    tbody.appendChild(tr);
                });
            }

            function renderConsumerGroups(data) {
                const activeEnv = document.querySelector('input[name="envRadio"]:checked').value;
                const tbody = document.getElementById('cgroupsBody');
                tbody.innerHTML = '';
                data.forEach(item => {
                    const tr = document.createElement('tr');
                    
                    let lagHtml = '-';
                    if (item.lag !== '-' && item.lag !== undefined) {
                        lagHtml = `<span class="badge bg-warning text-dark lag-value">${item.lag}</span>`;
                    } else {
                        lagHtml = `<span class="lag-value">-</span>`;
                    }
                    
                    const groupStr = item.consumerGroup ? item.consumerGroup.replace(/'/g, "\\'") : '';
                    
                    tr.innerHTML = `
                        <td><strong>${item.consumerGroup}</strong></td>
                        <td><span class="badge bg-secondary">${item.topics || 'No topics assigned'}</span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary py-0 px-1 me-2 btn-refresh-lag" 
                                    onclick="refreshSingleLag(this, '${activeEnv}', '${groupStr}')" 
                                    title="Refresh only this lag limit">↻</button>
                            ${lagHtml}
                        </td>
                    `;
                    tbody.appendChild(tr);
                });
            }

            let currentConsumeTopic = '';
            
            document.getElementById('topicMessagesBackBtn').addEventListener('click', () => {
                document.getElementById('topicMessagesView').classList.add('d-none');
                document.getElementById('mainDashboardView').classList.remove('d-none');
            });

            document.getElementById('consumeModalRefreshBtn').addEventListener('click', () => {
                if (currentConsumeTopic) window.consumeTopic(null, currentConsumeTopic, true);
            });

            window.consumeTopic = function(btnElement, topic, skipModalShow = false) {
                currentConsumeTopic = topic;
                const activeEnv = document.querySelector('input[name="envRadio"]:checked').value;
                
                const tableCard = document.getElementById('consumeTableCard');
                const tbody = document.getElementById('consumeOutputBody');
                const spinner = document.getElementById('consumeSpinner');
                
                document.getElementById('consumeModalTopicName').innerText = `${topic}`;
                
                if (!skipModalShow) {
                    document.getElementById('mainDashboardView').classList.add('d-none');
                    document.getElementById('topicMessagesView').classList.remove('d-none');
                    tableCard.classList.add('d-none');
                    tbody.innerHTML = '';
                    spinner.classList.remove('d-none');
                    document.getElementById('consumeLastUpdated').innerHTML = `Last updated: Fetching...`;
                } else {
                    showToast('Loading latest messages...', 'primary');
                    document.getElementById('consumeLastUpdated').innerHTML = `Last updated: Fetching...`;
                }

                fetch(`/api/consume?env=${activeEnv}&topic=${encodeURIComponent(topic)}`)
                    .then(r => r.json())
                    .then(data => {
                        spinner.classList.add('d-none');
                        
                        // Update timestamp
                        const now = new Date();
                        const pad = num => num.toString().padStart(2, '0');
                        const timestampStr = `${now.getFullYear()}-${pad(now.getMonth()+1)}-${pad(now.getDate())} ${pad(now.getHours())}:${pad(now.getMinutes())}:${pad(now.getSeconds())}`;
                        document.getElementById('consumeLastUpdated').innerHTML = `Last updated: ${timestampStr}`;
                        
                        if (data.success) {
                            tbody.innerHTML = '';
                            if (data.data && data.data.length > 0) {
                                data.data.forEach(msg => {
                                    const p = msg.Partition !== undefined ? msg.Partition : '-';
                                    const o = msg.Offset !== undefined ? msg.Offset : '-';
                                    const t = msg.Timestamp || '-';
                                    const k = msg.Key || '-';
                                    const vType = typeof msg.Value === 'string' ? msg.Value : JSON.stringify(msg.Value);
                                    
                                    // format JSON nicely if it is json
                                    let vFormatted = msg.Value || '-';
                                    try {
                                        vFormatted = JSON.stringify(JSON.parse(vType), null, 2);
                                    } catch(e) {
                                        if(msg.raw) vFormatted = msg.raw;
                                    }
                                    
                                    const tr = document.createElement('tr');
                                    tr.innerHTML = `
                                        <td class="ps-3"><span class="badge bg-secondary text-white border">${o}</span></td>
                                        <td>${p}</td>
                                        <td class="text-muted">${t}</td>
                                        <td class="text-truncate" style="max-width:150px;" title="${k}">${k}</td>
                                        <td><pre class="m-0" style="white-space: pre-wrap; word-wrap: break-word; background:none; font-size: 13px; font-family:monospace; color: inherit;">${vFormatted}</pre></td>
                                    `;
                                    tbody.appendChild(tr);
                                });
                                tableCard.classList.remove('d-none');
                            } else if (data.raw) {
                                tbody.innerHTML = `<tr><td colspan="5"><pre class="m-0 p-2">${data.raw}</pre></td></tr>`;
                                tableCard.classList.remove('d-none');
                            } else {
                                tbody.innerHTML = `<tr><td colspan="5" class="text-center py-4 text-muted"><div class="fs-1 mb-2">&#128193;</div>No messages found.</td></tr>`;
                                tableCard.classList.remove('d-none');
                            }
                        } else {
                            if (!skipModalShow) {
                                tbody.innerHTML = `<tr><td colspan="5" class="text-center text-danger py-3 fw-bold">Error: ${data.message}</td></tr>`;
                                tableCard.classList.remove('d-none');
                            }
                            if (data.message.includes('wait')) {
                                showToast(data.message, 'warning');
                            } else {
                                showToast(`Error: ${data.message}`, 'danger');
                            }
                        }
                    })
                    .catch(err => {
                        spinner.classList.add('d-none');
                        if (!skipModalShow) {
                            tbody.innerHTML = `<tr><td colspan="5" class="text-center text-danger py-3">Fetch Error: ${err}</td></tr>`;
                            tableCard.classList.remove('d-none');
                        } else {
                            showToast(`Fetch Error: ${err}`, 'danger');
                        }
                    });
            };

            window.refreshSingleLag = function(btnElement, env, group) {
                const td = btnElement.parentElement;
                const valSpan = td.querySelector('.lag-value');
                
                btnElement.disabled = true;
                const originalHtml = btnElement.innerHTML;
                btnElement.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true" style="width: 0.8rem; height: 0.8rem;"></span>`;
                
                fetch(`/api/refresh_lag?env=${encodeURIComponent(env)}&group=${encodeURIComponent(group)}`)
                    .then(r => r.json())
                    .then(res => {
                        if (res.success) {
                            if (res.lag !== '-') {
                                valSpan.outerHTML = `<span class="badge bg-warning text-dark lag-value">${res.lag}</span>`;
                            } else {
                                valSpan.outerHTML = `<span class="lag-value">-</span>`;
                            }
                            
                            // Aktualizujeme i místní array `cgroupsData` pro fungování filtrů/stránkování
                            const cg = cgroupsData.find(c => c.consumerGroup === group);
                            if (cg) cg.lag = res.lag;
                        } else {
                            valSpan.outerHTML = `<span class="badge bg-danger lag-value">Err</span>`;
                            console.error(res.message);
                        }
                    })
                    .catch(err => {
                        console.error('Lag refresh failed', err);
                        valSpan.outerHTML = `<span class="badge bg-danger lag-value">Err</span>`;
                    })
                    .finally(() => {
                        btnElement.disabled = false;
                        btnElement.innerHTML = originalHtml;
                    });
            };

        });
