#!/usr/bin/env python3
import json
import logging
import urllib.parse
import re
import requests
import urllib3
import os
from utils import config, check_cooldown, trigger_cooldown, create_ssh_client, run_ssh_command, ensure_dir

urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)

GRAFANA_URL = config.get("grafana_url")
GRAFANA_API_TOKEN = config.get("grafana_api_token")
DATASOURCE_ID = config.get("datasource_id")

def get_consumer_group_lags(job_name):
    """Gets the latest sum lag for all active consumer groups from Prometheus."""
    try:
        query = f"sum by (consumergroup, topic) (kafka_consumergroup_lag{{job='{job_name}'}})"
        
        logging.info(f"Downloading lags from Grafana proxy for job '{job_name}'")
        
        api_endpoint = f"{GRAFANA_URL}/api/datasources/proxy/{DATASOURCE_ID}/api/v1/query"
        response = requests.get(
            api_endpoint,
            params={'query': query},
            headers={"Authorization": f"Bearer {GRAFANA_API_TOKEN}"},
            verify=False,
            timeout=10
        )
        response.raise_for_status()
        
        response_data = response.json()
        if response_data.get('status') != 'success':
            logging.error(f"Error in Prometheus response: {response_data}")
            return {}

        results = response_data.get('data', {}).get('result', [])
        
        lags_by_group = {}
        for result in results:
            metric = result.get('metric', {})
            if 'value' in result and len(result['value']) == 2:
                value = int(float(result['value'][1]))
            else:
                value = 0
                
            group = metric.get('consumergroup')
            if not group:
                continue
                
            if group not in lags_by_group:
                lags_by_group[group] = 0
            lags_by_group[group] += value
            
        logging.info(f"Loaded lag for {len(lags_by_group)} consumer groups.")
        return lags_by_group
        
    except Exception as e:
        logging.error(f"Failed to get lags from Prometheus via Grafana: {e}")
        return {}

def get_single_group_lag(env_name, group_name):
    """Gets the current lag from Prometheus for ONE specific consumer group."""
    environments = config.get("environments", {})
    env_cfg = environments.get(env_name.lower())
    if not env_cfg:
        return "-"
        
    job_name = env_cfg.get("prometheus_job")
    
    try:
        query = f"sum(kafka_consumergroup_lag{{job='{job_name}', consumergroup='{group_name}'}})"
        api_endpoint = f"{GRAFANA_URL}/api/datasources/proxy/{DATASOURCE_ID}/api/v1/query"
        
        response = requests.get(
            api_endpoint,
            params={'query': query},
            headers={"Authorization": f"Bearer {GRAFANA_API_TOKEN}"},
            verify=False,
            timeout=5
        )
        response.raise_for_status()
        response_data = response.json()

        if response_data.get('status') != 'success':
            return "-"

        results = response_data.get('data', {}).get('result', [])
        if not results:
            return "-"
            
        result = results[0]
        if 'value' in result and len(result['value']) == 2:
            return int(float(result['value'][1]))
            
        return "-"
    except Exception as e:
        logging.error(f"Failed to get lag for group {group_name}: {e}")
        return "-"

def process_consumer_groups(env_name, env_cfg):
    """Downloads consumer groups via SSH and connects to prometheus lag."""
    output_dir = ensure_dir(env_name)
    ssh_host = env_cfg.get("ssh_host")
    job_name = env_cfg.get("prometheus_job")
    
    ssh = create_ssh_client(ssh_host)
    if not ssh:
        return
        
    cg_output_string = run_ssh_command(ssh, "kafkactl get consumer-groups")
    prometheus_lags = get_consumer_group_lags(job_name)
    
    if cg_output_string:
         try:
            formatted_cgs = []
            lines = cg_output_string.strip().split('\n')
            
            header_idx = -1
            for idx, line in enumerate(lines):
                if "CONSUMER_GROUP" in line.upper():
                    header_idx = idx
                    break
                    
            if header_idx != -1 and len(lines) > header_idx:
                headers = [h.strip().lower().replace("_", "") for h in re.split(r'\s{2,}', lines[header_idx].strip())]
                
                for line in lines[header_idx+1:]:
                    if not line.strip(): continue
                    parts = [p.strip() for p in re.split(r'\s{2,}', line.strip())]
                    if len(parts) >= 1:
                        row_dict = dict(zip(headers, parts))
                        group_id = row_dict.get("consumergroup", parts[0] if len(parts) > 0 else "Unknown")
                        prometheus_lag = prometheus_lags.get(group_id, "-")
                        
                        formatted_cgs.append({
                            "consumerGroup": group_id,
                            "topics": row_dict.get("topics", parts[1] if len(parts) > 1 else "None / Inactive"),
                            "lag": prometheus_lag
                        })

            with open(os.path.join(output_dir, "consumer_groups.json"), "w", encoding='utf-8') as f:
                json.dump(formatted_cgs, f, indent=4)
            logging.info(f"[{env_name}] Consumer Groups successfully saved.")
         except Exception as ex:
            logging.error(f"[{env_name}] Failed to parse Consumer Groups output: {ex}")

    ssh.close()

def run_update_cgroups(force=False):
    """Executes update loop for consumer groups exclusively."""
    is_skipped, msg = check_cooldown(force)
    if is_skipped:
         return False, msg

    environments = config.get("environments", {})
    for env_name, env_cfg in environments.items():
        logging.info(f"--- CGROUPS [{env_name.upper()}] ---")
        process_consumer_groups(env_name, env_cfg)
            
    trigger_cooldown()
    return True, "Consumer groups synchronization successful."

if __name__ == "__main__":
    run_update_cgroups(force=True)
