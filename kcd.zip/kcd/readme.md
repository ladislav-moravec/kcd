# Kafka Configuration Dashboard (KCD)

A lightweight, multi-environment web dashboard for monitoring Kafka configurations, ACLs (Permissions), Consumer Groups, and real-time lag metrics via Prometheus and Grafana.

## Features

- **Multi-Environment Support**: Easily switch between DEV, QA, and PROD with dedicated tabs.
- **Topics & ACLs Management**: Fetches complete Kafka topic metadata (retention, cleanup policies, replicas) and granular Access Control Lists using `kafkactl` over SSH.
- **Live Lag Metrics**: Queries consumer group lag directly from Grafana's Prometheus proxy without requiring direct open ports to Prometheus.
- **Advanced Frontend UI**: Features column sorting, real-time search, HTML5 progress bars, and non-blocking Bootstrap Toast notifications.
- **CSV Data Export**: Export currently active and filtered table data directly to a CSV file directly from the browser.
- **URL State Persistence**: Your search terms, column filters, and active tabs are automatically saved in the URL parameters allowing you to share perfect views.
- **Offline Resources**: Uses locally hosted Bootstrap CSS & JS to ensure the dashboard works smoothly on closed corporate networks.
- **Micro-Refresh**: Quickly reload a lag value for a specific consumer group without waiting for a full server sync.
- **Anti-Spam Protection**: Built-in Python backend cooldown timers (default 5 min) prevent DDoS-ing the Kafka servers or the Grafana API.
- **Light/Dark Mode**: Built-in support for different visual themes.

---

## Project Structure

- **`app.py`**  
  The main entry point. A lightweight Flask web server that serves the frontend (`index.html`), JSON outputs, and exposes REST endpoints (`/api/refresh`, `/api/refresh_lag`) to trigger updates.

- **`index.html`**  
  The frontend view. Provides the user interface using local offline Bootstrap 5 resources. Features deeply interactive tables, global search bars, column-specific filters, sorting, CSV exports, toast notifications, UI URL state persistence, and pagination.

- **`config.json`**  
  The core configuration file. Here you define SSH settings, SSH keys, target environments (hostnames, Prometheus job names), Grafana API tokens, and cooldown timers.

- **`utils.py`**  
  A utility module sharing repetitive tasks across the project: loading `config.json`, evaluating cooldown timers, managing SSH connections (via `paramiko`), and executing CLI commands.

- **`update_data.py`**  
  The data orchestration script. Connects to the Kafka servers via SSH to fetch Topics and ACLs. Once finished, it triggers `update_consumer_groups.py`.

- **`update_consumer_groups.py`**  
  Handles Consumer Groups logic independently. Maps consumer group assignments via SSH (`kafkactl`) and matches them with real-time lag data scraped from Grafana. 

---

## Prerequisites

1. Python 3.7+
2. The `kafkactl` binary installed and configured on the target Linux servers.
3. Access to a Grafana Datastore Proxy configured for Prometheus.

---

## Installation

**1. Install dependencies**
Install the necessary Python libraries:
```bash
pip install flask paramiko requests urllib3
```

**2. Configure the Dashboard**
Update the `config.json` file in the root folder with your environment specifics:
- Set up `ssh_host`, `ssh_user`, and `ssh_key_path` for passwordless access to your Kafka servers.
- Specify the `prometheus_job` representing your cluster in Prometheus.
- Input your `grafana_url`, the `datasource_id`, and `grafana_api_token`.
- Project expects existing `kafka-ssh-key`, so make sure it exists or create it on OpenShift using command: 
```oc create secret generic kafka-ssh-key --from-file=id_rsa=PathToPK/id_rsa```

**3. Run the application**
Start the web server:
```bash
python app.py
```
By default, the application runs on `http://0.0.0.0:8080/`.

---

## API Endpoints

- `GET /` - Serves the web interface (`index.html`).
- `GET /data/<env>/<file>.json` - Serves statically generated cache data for Topics, ACLs, or Consumer Groups.
- `POST /api/refresh` - Triggers an asynchronous SSH + HTTP fetch to sync new metadata (controlled by `refresh_cooldown_minutes`).
- `GET /api/refresh_lag?env=qa&group=my_group` - Bypasses the cooldown timer safely to quickly fetch the lag for a *single* specified consumer group from prometeus (is not touching kafka at all).
